package com.example.myapplication

import android.nfc.Tag
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore


class MainActivity : AppCompatActivity() {
    lateinit var name:EditText
    lateinit var id:EditText
    lateinit var age: EditText
    private var db = FirebaseFirestore.getInstance()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var save =  findViewById<Button>(R.id.save)
        name = findViewById(R.id.PersonName)
        id = findViewById(R.id.PersonID)
        age = findViewById(R.id.PersonAge)
        save.setOnClickListener {
              name.text.toString();
            var id = id.text.toString();
            var age = age.text.toString();

            val person: MutableMap<String, Any> = HashMap()
            person["first"] = name
            person["last"] = id
            person["born"] = age

            db.collection("Person").
            add(person)
                .addOnSuccessListener {docunmentReference ->
                    Toast.makeText(applicationContext,"${docunmentReference.id}", Toast.LENGTH_LONG).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(applicationContext, "$e.", Toast.LENGTH_LONG).show()
                }

            // read
            db.collection("Person")
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        for (document in task.result) {
                            Toast.makeText(applicationContext, "${task.isSuccessful}", Toast.LENGTH_LONG).show()
//                            Log.d(TAG, document.id + " => " + document.data)
                        }
                    } else {
                        Toast.makeText(applicationContext, "${task.isCanceled}", Toast.LENGTH_LONG).show()
//                        Log.w(Tag, "Error getting documents.", task.exception)
                    }
                }
        }

//    id 'kotlin-android-extensions'
    }
}